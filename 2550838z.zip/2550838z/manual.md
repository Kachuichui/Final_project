# User manual 

The researcher built Unity on a macOS laptop to recreate the augmented reality situation. Using Unity Editor 2022.3.16f1.
Anothr device is Meta Quest 3. Use type-C cable to link Mac and Meta Quest 3. Also, It is convinent to downlowd the meta app in mobile phone. Register an account and go to setting to enble the developer mode. Then Go back to the Unity, Go to File -> Build Setting. Make sure the platform is Andorid. If not switch it to Andorid. And go to Run Service, select "Oculus Quest 3". If there doesn't exist this name. Click Refresh. Then, Click Build and Run.

After load the project to the Quest 3 headset, Test the headset in real-time by pressing the unknown source app in the Quest menu for smooth application execution and functionality assessment.
