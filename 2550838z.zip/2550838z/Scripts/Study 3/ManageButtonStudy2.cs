using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManageButtonStudy2 : MonoBehaviour
{
    public TimerStudy2 timerManage; 
    public GameObject canvas3;
    public GameObject canvas2;  
    public GameObject buttonPause;
    public GameObject buttonResume;
    
    private void Start()
    {
        buttonPause.SetActive(true);
        buttonResume.SetActive(false);
    }
    public void OnPauseButtonPointed()
    {

        if (buttonPause.activeSelf)
        {
            timerManage.Pause();
            buttonPause.SetActive(false);
            buttonResume.SetActive(true);
        }
    }

    public void OnResumeButtonPointed()
    {
 
        if (buttonResume.activeSelf)
        {
            timerManage.Resume();
            buttonResume.SetActive(false);
            buttonPause.SetActive(true);
        }
    }
    public void OnRestartButtonPointed()
    {

        timerManage.Restart();
    }

    public void OnDeleteButtonPointed()
    {
        timerManage.Delete();
    }



    public void ShowTargetCanvas()
    {


        if (canvas2.activeSelf)
        {
           
            canvas2.SetActive(false);
            canvas3.SetActive(true);
        }
        else if (canvas3.activeSelf)
        {
         
            canvas3.SetActive(false);
            canvas2.SetActive(true);
        }


    }


}
