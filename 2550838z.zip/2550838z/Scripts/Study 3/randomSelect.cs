using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class randomSelect: MonoBehaviour
{
   
    public GameObject[] allTimers;
    public AudioSource audioSource;
    private Vector3[] originalScales;

    void Start()
    {
        originalScales = new Vector3[allTimers.Length];
        for (int i = 0; i < allTimers.Length; i++)
        {
            originalScales[i] = allTimers[i].transform.localScale;
        }
        StartCoroutine(RandomTimerSelectionRoutine());
    }

    private IEnumerator RandomTimerSelectionRoutine()
    {
        bool isFirstExecution = true;
        yield return new WaitForSeconds(30f);
        while (true)
        {
            if (!isFirstExecution)
            {
                // 如果不是第一次执行，则等待一个周期的结束
                yield return new WaitForSeconds(60f);
            }
            else
            {
                isFirstExecution = false;
            }

            // 随机选择一个Timer
            int index = Random.Range(0, allTimers.Length);
            GameObject selectedTimer = allTimers[index];

            // 执行放大缩小动画
            audioSource.Play();
            StartCoroutine(ScaleObject(selectedTimer, originalScales[index], 2f, 1f));
            yield return new WaitForSeconds(5f);
            StartCoroutine(ScaleObject(selectedTimer, originalScales[index], 1f, 1f));
            //StartCoroutine(ScaleObject(selectedTimer, 2f, 1f)); // 放大到1.2倍，持续0.5秒
            //yield return new WaitForSeconds(5f); // 等待1秒
            //StartCoroutine(ScaleObject(selectedTimer, 1f / 2f, 1f)); // 缩小到原始大小，持续0.5秒
            audioSource.Stop();
        }
    }


    //private IEnumerator ScaleObject(GameObject obj, float scale, float duration)
    //{
    //    Vector3 originalScale = obj.transform.localScale;
    //    Vector3 targetScale = originalScale * scale;
    //    float timer = 0;

    //    while (timer <= duration)
    //    {
    //        float t = timer / duration;
    //        obj.transform.localScale = Vector3.Lerp(originalScale, targetScale, t);
    //        timer += Time.deltaTime;
    //        yield return null;
    //    }

    //    obj.transform.localScale = targetScale;
    //}
    private IEnumerator ScaleObject(GameObject obj, Vector3 originalScale, float scale, float duration)
    {
        Vector3 targetScale = originalScale * scale;
        float timer = 0;

        while (timer <= duration)
        {
            float t = timer / duration;
            obj.transform.localScale = Vector3.Lerp(originalScale, targetScale, t);
            timer += Time.deltaTime;
            yield return null;
        }

        obj.transform.localScale = targetScale;
    }


}
