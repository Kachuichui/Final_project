using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
public class UIButtons : MonoBehaviour
{
    public TimerManage timerManage;
    public GameObject canvas3;
    public GameObject canvas2;

    public void OnPauseButtonPointed()
    {
        timerManage.Pause();
    }

    public void OnResumeButtonPointed()
    {
        timerManage.Resume();
    }

    public void OnRestartButtonPointed()
    {

        timerManage.Restart();
    }
    public void OnMainButtonPointed()
    {
        timerManage.mainPanel();
    }
    public void OnDeleteButtonPointed()
    {
        timerManage.Delete();
    }



    public void ShowTargetCanvas()
    {


        if (canvas2.activeSelf)
        {

            canvas2.SetActive(false);
            canvas3.SetActive(true);
        }
        else if (canvas3.activeSelf)
        {

            canvas3.SetActive(false);
            canvas2.SetActive(true);
        }


    }


}
