using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Unity.VisualScripting;
using UnityEngine.SceneManagement;
public class TimerManage : MonoBehaviour
{
    [SerializeField] private Image uiFill; 
    [SerializeField] private TMP_Text uiText; 

    [SerializeField] private Slider uiSlider; 
    [SerializeField] private TMP_Text uiSliderText; 
    [SerializeField] private GameObject circularTimer; 
    [SerializeField] private GameObject sliderTimer; 
    public GameObject canvas1;
    public GameObject canvas2;
    public GameObject canvas3;
    public GameObject timerPrefab;
    public TMP_Text storeNumber;
    public AudioSource alarmAudioSource;



    private int Duration; 
    private int remainingDuration; 
    private bool isPaused = false;
    private Image sliderBackground;
    private bool hasScaledUp = false;
    private bool isplay = false;

    public void Being(int minutes)
    {
        print("minutes is : " + minutes);
        Duration = minutes * 60;
        remainingDuration = Duration;
        Debug.Log($"Timer started with duration: {Duration} seconds.");
        if (uiSlider != null) {
            uiSlider.maxValue = remainingDuration;
            uiSlider.value = remainingDuration;
        }
        StartCoroutine(UpdateTimer());
        print("start");
    }

 


    public void Pause()
    {
        isPaused = true;
        alarmAudioSource.Stop();
    }
 
    public void Resume()
    {
        isPaused = false;
    }
    public void Delete()
    {
        if (timerPrefab != null) 
        {
            Destroy(timerPrefab); 
            timerPrefab = null; 
        }
    }

 
    public void Restart()
    {
        if (hasScaledUp == true) { switchBackUI();}
        if (int.TryParse(storeNumber.text, out int newTime))
        {
            isPaused = false;
            StopAllCoroutines();
            Being(newTime);
        }
        else
        {
            Debug.LogError("Invalid time in storeNumber.text, unable to parse.");
        }
    }
    public void mainPanel() {
        if (hasScaledUp == true) {switchBackUI();}
        
            canvas1.SetActive(true);
            canvas2.SetActive(false);
            canvas3.SetActive(false);
         
            StopAllCoroutines();
            isPaused = false;
            
            storeNumber.text = "0";
            Being(0); 

      
            UpdateUI();


    }

    private IEnumerator UpdateTimer()
    {
        float timer = remainingDuration;
        while (timer > 0)
        {
            if (!isPaused)
            {
                timer -= Time.deltaTime;
                remainingDuration = Mathf.FloorToInt(timer);
                isplay = true;
                UpdateUI();

            }
            yield return null;
        }
        OnEnd();
    }


    private void UpdateUI() {
 
        int minutes = remainingDuration / 60;
        int seconds = remainingDuration % 60;
        string text = string.Format("{0:00}:{1:00}", minutes, seconds);
        sliderBackground = uiSlider.transform.Find("Background").GetComponent<Image>();

        // update circle fillAmount
        uiText.text = text;
        uiFill.fillAmount = Mathf.InverseLerp(0, Duration, remainingDuration);

        // update slider value
        uiSliderText.text = text;
        uiSlider.value = remainingDuration;

        if ((0 < remainingDuration) && (remainingDuration <= (Duration * 0.2f)) && !hasScaledUp)
        {
            //Duration * 0.2f
            uiText.color = new Color32(0xC8, 0x6D, 0x65, 0xFF); // 深色
            uiFill.color = new Color32(0xC8, 0x6D, 0x65, 0xFF); // 深色

            sliderBackground.color = new Color32(0xC8, 0x6D, 0x65, 0xFF);
            uiSliderText.color = new Color32(0xC8, 0x6D, 0x65, 0xFF);

            if (isplay) { alarmAudioSource.Play(); }

            Debug.Log(timerPrefab.transform.localScale);
            timerPrefab.transform.localScale *= 2.0f;
         
            Image image = timerPrefab.GetComponentInChildren<Image>(); // 假设你的Prefab有一个Image组件
            if (image != null)
            {
                byte desiredAlpha = 240;
                image.color = new Color32(0xC8, 0x6D, 0x65, desiredAlpha); // 设置为红色
                uiText.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
                uiFill.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);

                uiSliderText.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
                sliderBackground.color = new Color32(0x78, 0x93, 0x85, 0xFF);
            }

            hasScaledUp = true;

        }
        else if (remainingDuration > (Duration * 0.2f) && hasScaledUp)
        {
            hasScaledUp = false;
           

        }
    }
    public void switchBackUI() {
        uiText.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
        uiFill.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
        uiSliderText.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
        sliderBackground.color = new Color32(0x78, 0x93, 0x85, 0xFF);
        timerPrefab.transform.localScale /= 2.0f;
        Image image = timerPrefab.GetComponentInChildren<Image>();
        if (image != null)
        {
            byte desiredAlpha = 145;
            image.color = new Color32(0x93, 0xB2, 0xA2, desiredAlpha); 
          
        }
        hasScaledUp = false;


    }
    
  
    private void OnEnd()
    {
        uiText.text = "00:00";
        uiSliderText.text = "00:00";
        uiFill.fillAmount = 0;
        uiSlider.value = 0;
        alarmAudioSource.Stop();


    }
}
