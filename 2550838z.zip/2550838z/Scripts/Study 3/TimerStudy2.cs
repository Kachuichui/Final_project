using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class TimerStudy2 : MonoBehaviour
{
    [SerializeField] private Image uiFill;
    [SerializeField] private TMP_Text uiText;
    [SerializeField] private Slider uiSlider;
    [SerializeField] private TMP_Text uiSliderText;
    public GameObject canvas2;
    public GameObject canvas3;
    public GameObject timerPrefab;
    public int storeNumber = 1;
    public AudioSource alarmAudioSource;
    private Image sliderBackground;

    private int Duration;
    private int remainingDuration;
    private bool isPaused = false;
    private bool hasScaledUp = false;
    private Vector3 originalScale; // use to store the originginal size for timeprefab

    private void Start()
    {
        canvas2.SetActive(true);
        canvas3.SetActive(false);
        originalScale = timerPrefab.transform.localScale; 
        sliderBackground = uiSlider.transform.Find("Background").GetComponent<Image>(); // 初始化sliderBackground
    }


    public void Being(int minutes)
    {
        print("minutes is : " + minutes);
        Duration = minutes * 60;
        remainingDuration = Duration;
        Debug.Log($"Timer started with duration: {Duration} seconds.");
        if (uiSlider != null)
        {
            uiSlider.maxValue = remainingDuration;
            uiSlider.value = remainingDuration;
        }
        StartCoroutine(UpdateTimer());
    }

    public void Play()
    {
        StopAllCoroutines();
        hasScaledUp = false;
        timerPrefab.transform.localScale = originalScale; 

        Being(storeNumber);
        canvas2.SetActive(true);
        canvas3.SetActive(false);
    }

    public void Pause()
    {
        isPaused = true;
        alarmAudioSource.Stop();
    }

    public void Resume()
    {
        isPaused = false;
    }

    public void Delete()
    {
        if (timerPrefab != null)
        {
            Destroy(timerPrefab);
            timerPrefab = null;
        }
    }

    public void Restart()
    {
        StopAllCoroutines();
        hasScaledUp = false;
        timerPrefab.transform.localScale = originalScale; 
        isPaused = false;
        Being(storeNumber);
    }

    private IEnumerator UpdateTimer()
    {
        float timer = remainingDuration;
        while (timer > 0)
        {
            if (!isPaused)
            {
                timer -= Time.deltaTime;
                remainingDuration = Mathf.FloorToInt(timer);
                UpdateUI();
            }
            yield return null;
        }
        OnEnd();
    }

    private void UpdateUI()
    {
        int minutes = remainingDuration / 60;
        int seconds = remainingDuration % 60;
        string text = string.Format("{0:00}:{1:00}", minutes, seconds);
        uiText.text = text;
        uiFill.fillAmount = Mathf.InverseLerp(0, Duration, remainingDuration);
        uiSliderText.text = text;
        uiSlider.value = remainingDuration;

        if (remainingDuration <= 5f && !hasScaledUp)
        {
            hasScaledUp = true;
            alarmAudioSource.Play();
            Image image = timerPrefab.GetComponentInChildren<Image>(); 
            if (image != null)
            {
                byte desiredAlpha = 240;
                image.color = new Color32(0xC8, 0x6D, 0x65, desiredAlpha);
                uiText.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
                uiFill.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);

                uiSliderText.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
                sliderBackground.color = new Color32(0x78, 0x93, 0x85, 0xFF);
                StartCoroutine(ScaleObject(timerPrefab, 2.0f)); // enlarge
            }
        } }

    private IEnumerator ScaleObject(GameObject obj, float scale)
    {
        Vector3 targetScale = originalScale * scale;
        obj.transform.localScale = targetScale;
        yield return new WaitForSeconds(5f); 
        obj.transform.localScale = originalScale; 
        switchBackUI();
        hasScaledUp = false;
    }
    public void switchBackUI()
    {
        uiText.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
        uiFill.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
        uiSliderText.color = new Color32(0xF4, 0xF4, 0xE3, 0xFF);
        sliderBackground.color = new Color32(0x78, 0x93, 0x85, 0xFF);
        timerPrefab.transform.localScale = originalScale;
       
        Image image = timerPrefab.GetComponentInChildren<Image>();
        if (image != null)
        {
            byte desiredAlpha = 145; 
            image.color = new Color32(0x93, 0xB2, 0xA2, desiredAlpha); 
        }
    }
    public void OnEnd()
        {
            uiText.text = "00:00";
            uiSliderText.text = "00:00";
            uiFill.fillAmount = 0;
            uiSlider.value = 0;
            alarmAudioSource.Stop();
            timerPrefab.transform.localScale = originalScale; 
            hasScaledUp = false;
        }
    } 

