using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimerGenerator : MonoBehaviour
{
    public GameObject timerPrefab; 
    public OVRHand handRefLeft; 
    public OVRSkeleton skeletonLeft; 
    public OVRHand handRefRight; 
    public OVRSkeleton skeletonRight; 


    public void GenerateTimerLeft()
    {
        // check hand be 
        if (handRefLeft.IsTracked && skeletonLeft.IsDataValid && skeletonLeft.IsDataHighConfidence
            )
        {
            GenerateTimer(skeletonLeft);
        }
    }
    public void GenerateTimerRight()
    {
        
       
        if (handRefRight.IsTracked && skeletonRight.IsDataValid && skeletonRight.IsDataHighConfidence
        )
        {
            GenerateTimer(skeletonRight);
        }
    }

    private void GenerateTimer(OVRSkeleton skeleton)
    {
        // get finger tip bone id
        OVRBone boneIndexTip = skeleton.Bones[(int)OVRSkeleton.BoneId.Hand_IndexTip];
        if (boneIndexTip != null)
        {
            // finger tip position
            Vector3 fingerTipPosition = boneIndexTip.Transform.position;
            Quaternion headRotation = Camera.main.transform.rotation;

          
            Instantiate(timerPrefab, fingerTipPosition, headRotation);
        }

    }




}

