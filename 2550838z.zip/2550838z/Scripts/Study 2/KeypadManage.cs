using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;



public class KeypadManage : MonoBehaviour
{
    public TMP_Text outputText; 
    public GameObject Canvas1; 
    public GameObject Canvas2;
    public GameObject Canvas3;
    public int storedNumber;
    public TimerManage timerManage;

    void Start()
    {
        Canvas1.SetActive(true);
        Canvas3.SetActive(false);
        Canvas2.SetActive(false);
    }
    public void AddNumber(string number)
    {
        outputText.text += number;
    }
    public void ClearNumber()
    {
        outputText.text = "";
    }
    public void StartAndStoreNumber()
    {
        storedNumber = int.Parse(outputText.text);
        timerManage.Being(storedNumber);
        Canvas2.SetActive(true);
        Canvas1.SetActive(false);
    }

}


    

